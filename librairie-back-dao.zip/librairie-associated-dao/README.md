# Book Manager Back

## Description

Back-end JPA mappant deux entitées "Book" et "Authors" sur des Controlers REST.

Les URLS: ** */api/books** ** */api/authors**

## Paramétrage

Par défault: mappé sur une base locale Mysql 'librairie' avec identifiants: root@passwd. Les controlleurs REST sont accéssible depuis l'exterieur.

## TODO 
 - Validation de formulaires.
 - Script SQL par default.
