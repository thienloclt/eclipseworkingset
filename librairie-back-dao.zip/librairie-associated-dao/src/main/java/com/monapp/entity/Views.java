package com.monapp.entity;

public class Views {
	public static class Common{
		
	}
	
	public static class Book extends Common{
		
	}
	
	public static class Author extends Common{
		
	}
	
	public static class BookWithAuthors extends Book{
		
	}
	public static class AuthorWithBooks extends Author{
		
	}
	
}
