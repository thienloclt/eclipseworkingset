package com.monapp.dao;

import com.monapp.entity.Book;

public interface BookDao extends GenericDao<Book, Integer>{

	
	

}
