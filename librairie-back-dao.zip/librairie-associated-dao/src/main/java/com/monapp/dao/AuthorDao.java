package com.monapp.dao;

import com.monapp.entity.Author;

public interface AuthorDao extends GenericDao<Author, Integer>{

}
