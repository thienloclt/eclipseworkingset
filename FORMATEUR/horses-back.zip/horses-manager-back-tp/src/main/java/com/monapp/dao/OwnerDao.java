package com.monapp.dao;

import com.monapp.entity.Owner;
import com.monapp.entity.Registre;

public interface OwnerDao extends GenericDao<Owner, Integer>{

}
