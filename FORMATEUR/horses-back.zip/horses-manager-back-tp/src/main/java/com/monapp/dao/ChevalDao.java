package com.monapp.dao;

import com.monapp.entity.Cheval;

public interface ChevalDao extends GenericDao<Cheval, Integer>{

}
