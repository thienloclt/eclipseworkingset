package com.monapp.dao;

import com.monapp.entity.Registre;

public interface RegistreDao extends GenericDao<Registre, Integer>{

}
