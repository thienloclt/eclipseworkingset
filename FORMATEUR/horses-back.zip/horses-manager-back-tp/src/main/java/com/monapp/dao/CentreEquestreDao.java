package com.monapp.dao;

import com.monapp.entity.CentreEquestre;

public interface CentreEquestreDao extends GenericDao<CentreEquestre, Integer>{

}
