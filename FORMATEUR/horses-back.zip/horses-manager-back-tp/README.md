# Horses-Manager-Back
4 entités, leurs DAOs

## Connexion en base.
 - Nom de la base: ce
 - Identifiants: root@passwd
 - Base par défault: MySQL
