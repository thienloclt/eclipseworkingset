package com.monapp.metier;

public enum Role {
	USER,ADMIN
}
