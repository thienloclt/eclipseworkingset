package com.monapp.dao;

import com.monapp.metier.Artiste;

public interface ArtisteDao extends GenericDao<Artiste, Integer>{

	
	

}
