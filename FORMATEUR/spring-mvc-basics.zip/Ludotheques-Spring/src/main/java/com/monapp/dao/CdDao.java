package com.monapp.dao;

import com.monapp.metier.Artiste;
import com.monapp.metier.CD;

public interface CdDao extends GenericDao<CD, Integer>{

}
